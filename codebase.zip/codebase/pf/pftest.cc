#include <fstream>
#include <iostream>
#include <cassert>

#include "pf.h"

using namespace std;


void pfTest()
{
  // PF_Manager *pf = PF_Manager::Instance();

  // write your own testing cases here
}


int main() 
{
  cout << "test..." << endl;

  pfTest();
  // other tests go here

  cout << "OK" << endl;
}
